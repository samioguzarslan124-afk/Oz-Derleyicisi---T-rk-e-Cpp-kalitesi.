import type { Diagnostic, Position, Token } from "./types";

const keywords = new Set([
  "tam",
  "ondalik",
  "metin",
  "mantik",
  "bos",
  "dogru",
  "yanlis",
  "eger",
  "degilse",
  "dongu",
  "iken",
  "kir",
  "devam",
  "program",
  "fonksiyon",
  "dondur",
  "yazdir",
  "oku",
]);
const twoOps = ["==", "!=", "<=", ">=", "&&", "||", "->"];
export function lex(source: string): {
  tokens: Token[];
  diagnostics: Diagnostic[];
} {
  const tokens: Token[] = [],
    diagnostics: Diagnostic[] = [];
  let i = 0,
    line = 1,
    column = 1;
  const pos = (): Position => ({ line, column });
  const advance = () => {
    const c = source[i++];
    if (c === "\n") {
      line++;
      column = 1;
    } else column++;
    return c;
  };
  while (i < source.length) {
    const c = source[i];
    if (/\s/.test(c)) {
      advance();
      continue;
    }
    const at = pos();
    if (c === "/" && source[i + 1] === "/") {
      while (i < source.length && source[i] !== "\n") advance();
      continue;
    }
    if (c === "/" && source[i + 1] === "*") {
      advance();
      advance();
      let closed = false;
      while (i < source.length) {
        if (source[i] === "*" && source[i + 1] === "/") {
          advance();
          advance();
          closed = true;
          break;
        }
        advance();
      }
      if (!closed)
        diagnostics.push({
          ...at,
          category: "lexical",
          message: "Kapatılmamış blok yorumu.",
        });
      continue;
    }
    if (/[\p{L}_]/u.test(c)) {
      let v = "";
      while (i < source.length && /[\p{L}\p{N}_]/u.test(source[i]))
        v += advance();
      tokens.push({ kind: keywords.has(v) ? v : "identifier", value: v, at });
      continue;
    }
    if (/[0-9]/.test(c)) {
      let v = "";
      while (i < source.length && /[0-9]/.test(source[i])) v += advance();
      if (source[i] === "." && /[0-9]/.test(source[i + 1] || "")) {
        v += advance();
        while (i < source.length && /[0-9]/.test(source[i])) v += advance();
      }
      tokens.push({ kind: "number", value: v, at });
      continue;
    }
    if (c === '"' || c === "'") {
      const q = advance();
      let v = "",
        closed = false;
      while (i < source.length) {
        const x = advance();
        if (x === q) {
          closed = true;
          break;
        }
        if (x === "\\" && i < source.length) {
          const e = advance();
          v += e === "n" ? "\n" : e === "t" ? "\t" : e === "r" ? "\r" : e;
        } else v += x;
      }
      if (!closed)
        diagnostics.push({
          ...at,
          category: "lexical",
          message: "Kapatılmamış metin sabiti.",
        });
      tokens.push({ kind: "string", value: v, at });
      continue;
    }
    const two = source.slice(i, i + 2);
    if (twoOps.includes(two)) {
      advance();
      advance();
      tokens.push({ kind: two, value: two, at });
      continue;
    }
    if ("+-*/%=<>!{}()[];,".includes(c)) {
      advance();
      tokens.push({ kind: c, value: c, at });
      continue;
    }
    diagnostics.push({
      ...at,
      category: "lexical",
      message: `Tanınmayan karakter: ${c}`,
    });
    advance();
  }
  tokens.push({ kind: "eof", value: "", at: pos() });
  return { tokens, diagnostics };
}
