export type ValueType =
  | "tam"
  | "ondalik"
  | "metin"
  | "mantik"
  | "bos"
  | "tam[]"
  | "ondalik[]"
  | "metin[]"
  | "mantik[]";
export type Position = { line: number; column: number };
export type DiagnosticCategory = "lexical" | "syntax" | "semantic" | "runtime";
export type Diagnostic = Position & {
  category: DiagnosticCategory;
  kind?: string;
  message: string;
};
export type Token = { kind: string; value: string; at: Position };

export type Expr =
  | { kind: "literal"; value: Value; at: Position }
  | { kind: "variable"; name: string; at: Position }
  | { kind: "array"; items: Expr[]; at: Position }
  | { kind: "unary"; op: string; operand: Expr; at: Position }
  | { kind: "binary"; op: string; left: Expr; right: Expr; at: Position }
  | { kind: "call"; name: string; args: Expr[]; at: Position }
  | { kind: "index"; target: Expr; index: Expr; at: Position };
export type Stmt =
  | { kind: "block"; body: Stmt[]; at: Position }
  | {
      kind: "declare";
      name: string;
      type: ValueType;
      init?: Expr;
      at: Position;
    }
  | { kind: "assign"; target: Expr; value: Expr; at: Position }
  | { kind: "expr"; expr: Expr; at: Position }
  | { kind: "if"; test: Expr; yes: Stmt; no?: Stmt; at: Position }
  | { kind: "while"; test: Expr; body: Stmt; at: Position }
  | {
      kind: "for";
      init?: Stmt;
      test?: Expr;
      step?: Stmt;
      body: Stmt;
      at: Position;
    }
  | { kind: "break" | "continue"; at: Position }
  | { kind: "return"; value?: Expr; at: Position }
  | { kind: "print"; value: Expr; at: Position }
  | { kind: "input"; prompt?: Expr; target: Expr; at: Position }
  | {
      kind: "function";
      name: string;
      params: { name: string; type: ValueType }[];
      returns: ValueType;
      body: Stmt;
      at: Position;
    };
export type Program = { kind: "program"; body: Stmt[] };
export type Value = number | string | boolean | null | Value[];
export type RunResult =
  | { ok: true; output: string; value?: Value }
  | { ok: false; output: string; error: string; diagnostics: Diagnostic[] };
export type HostIO = {
  read: (prompt: string, type: ValueType) => string | Promise<string>;
  write: (value: string) => void;
};
