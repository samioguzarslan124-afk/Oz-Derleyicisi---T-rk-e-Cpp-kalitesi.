import type {
  Diagnostic,
  Expr,
  Program,
  Stmt,
  Token,
  Value,
  ValueType,
} from "./types";

export class ParseError extends Error {
  constructor(public diagnostic: Diagnostic) {
    super(diagnostic.message);
  }
}
export class Parser {
  private i = 0;
  constructor(private t: Token[]) {}
  private get p() {
    return this.t[this.i];
  }
  private take() {
    return this.t[this.i++];
  }
  private is(k: string) {
    return this.p.kind === k;
  }
  private match(k: string) {
    if (this.is(k)) {
      this.take();
      return true;
    }
    return false;
  }
  private need(k: string, msg = `'${k}' bekleniyordu.`) {
    if (!this.is(k))
      throw new ParseError({ ...this.p.at, category: "syntax", message: msg });
    return this.take();
  }
  parse(): Program {
    const body: Stmt[] = [];
    let hasEntry = false;
    while (!this.is("eof")) {
      if (this.match("program")) {
        if (hasEntry)
          throw new ParseError({
            ...this.p.at,
            category: "syntax",
            message: "Yalnızca bir program bloğu tanımlanabilir.",
          });
        if (this.is("identifier")) this.take();
        if (!this.is("{"))
          throw new ParseError({
            ...this.p.at,
            category: "syntax",
            message: "program adından sonra { bekleniyordu.",
          });
        body.push(this.statement());
        hasEntry = true;
      } else body.push(this.statement());
    }
    if (!hasEntry)
      throw new ParseError({
        ...this.p.at,
        category: "syntax",
        message: "Program bir program bloğu içermelidir.",
      });
    return { kind: "program", body };
  }
  private statement(): Stmt {
    const at = this.p.at;
    if (this.match("{")) {
      const body: Stmt[] = [];
      while (!this.is("}") && !this.is("eof")) body.push(this.statement());
      this.need("}");
      return { kind: "block", body, at };
    }
    if (
      this.is("tam") ||
      this.is("ondalik") ||
      this.is("metin") ||
      this.is("mantik") ||
      this.is("bos")
    ) {
      const type = this.type();
      const name = this.need("identifier", "Değişken adı bekleniyordu.").value;
      let init: Expr | undefined;
      if (this.match("=")) init = this.expression();
      this.need(";", "Bildirim sonunda ; bekleniyordu.");
      return { kind: "declare", name, type, init, at };
    }
    if (this.match("fonksiyon")) {
      let returns: ValueType = "bos";
      if (["tam", "ondalik", "metin", "mantik", "bos"].includes(this.p.kind))
        returns = this.type();
      const name = this.need("identifier").value;
      this.need("(");
      const params: { name: string; type: ValueType }[] = [];
      if (!this.is(")"))
        do {
          const type = this.type(),
            n = this.need("identifier").value;
          params.push({ name: n, type });
        } while (this.match(","));
      this.need(")");
      if (this.match(":")) returns = this.type();
      const body = this.statement();
      return { kind: "function", name, params, returns, body, at };
    }
    if (this.match("eger")) {
      this.need("(");
      const test = this.expression();
      this.need(")");
      const yes = this.statement();
      const no = this.match("degilse") ? this.statement() : undefined;
      return { kind: "if", test, yes, no, at };
    }
    if (this.match("dongu")) {
      this.need("(");
      let init: Stmt | undefined;
      if (!this.is(";")) init = this.simpleHeader();
      this.need(";");
      const test = this.is(";") ? undefined : this.expression();
      this.need(";");
      let step: Stmt | undefined;
      if (!this.is(")")) step = this.simpleHeader();
      this.need(")");
      return { kind: "for", init, test, step, body: this.statement(), at };
    }
    if (this.match("iken")) {
      this.need("(");
      const test = this.expression();
      this.need(")");
      return { kind: "while", test, body: this.statement(), at };
    }
    if (this.match("kir")) {
      this.need(";");
      return { kind: "break", at };
    }
    if (this.match("devam")) {
      this.need(";");
      return { kind: "continue", at };
    }
    if (this.match("dondur")) {
      const value = this.is(";") ? undefined : this.expression();
      this.need(";");
      return { kind: "return", value, at };
    }
    if (this.match("yazdir")) {
      this.need("(");
      const value = this.expression();
      this.need(")");
      this.need(";");
      return { kind: "print", value, at };
    }
    if (this.match("oku")) {
      this.need("(");
      const first = this.expression();
      this.need(")");
      let prompt: Expr | undefined;
      let target = first;
      if (this.match("->")) {
        prompt = first;
        target = this.expression();
      }
      this.need(";");
      return { kind: "input", prompt, target, at };
    }
    const expr = this.expression();
    if (this.match("=")) {
      const value = this.expression();
      this.need(";");
      return { kind: "assign", target: expr, value, at };
    }
    this.need(";");
    return { kind: "expr", expr, at };
  }
  private type(): ValueType {
    const base = this.take();
    if (!["tam", "ondalik", "metin", "mantik", "bos"].includes(base.kind))
      throw new ParseError({
        ...base.at,
        category: "syntax",
        message: "Tür bekleniyordu.",
      });
    return (
      this.match("[") ? (this.need("]"), `${base.kind}[]`) : base.kind
    ) as ValueType;
  }
  private simpleHeader(): Stmt {
    const at = this.p.at;
    if (["tam", "ondalik", "metin", "mantik", "bos"].includes(this.p.kind)) {
      const type = this.type(),
        name = this.need("identifier").value;
      const init = this.match("=") ? this.expression() : undefined;
      return { kind: "declare", name, type, init, at };
    }
    const target = this.expression();
    if (this.match("="))
      return { kind: "assign", target, value: this.expression(), at };
    return { kind: "expr", expr: target, at };
  }
  private expression(min = 0): Expr {
    let left = this.prefix();
    const prec: Record<string, number> = {
      "||": 1,
      "&&": 2,
      "==": 3,
      "!=": 3,
      "<": 4,
      ">": 4,
      "<=": 4,
      ">=": 4,
      "+": 5,
      "-": 5,
      "*": 6,
      "/": 6,
      "%": 6,
    };
    while ((prec[this.p.kind] || 0) > min) {
      const op = this.take(),
        right = this.expression(prec[op.kind]);
      left = { kind: "binary", op: op.kind, left, right, at: op.at };
    }
    return left;
  }
  private prefix(): Expr {
    const t = this.take();
    let e: Expr;
    if (t.kind === "number")
      e = { kind: "literal", value: Number(t.value), at: t.at };
    else if (t.kind === "string")
      e = { kind: "literal", value: t.value, at: t.at };
    else if (t.kind === "dogru" || t.kind === "yanlis")
      e = { kind: "literal", value: t.kind === "dogru", at: t.at };
    else if (
      t.kind === "! " ||
      t.kind === "!" ||
      t.kind === "-" ||
      t.kind === "+"
    )
      e = { kind: "unary", op: t.kind, operand: this.expression(7), at: t.at };
    else if (t.kind === "(") {
      e = this.expression();
      this.need(")");
    } else if (t.kind === "[") {
      const items: Expr[] = [];
      if (!this.is("]"))
        do {
          items.push(this.expression());
        } while (this.match(","));
      this.need("]");
      e = { kind: "array", items, at: t.at };
    } else if (t.kind === "identifier") {
      if (this.match("(")) {
        const args: Expr[] = [];
        if (!this.is(")"))
          do {
            args.push(this.expression());
          } while (this.match(","));
        this.need(")");
        e = { kind: "call", name: t.value, args, at: t.at };
      } else e = { kind: "variable", name: t.value, at: t.at };
    } else
      throw new ParseError({
        ...t.at,
        category: "syntax",
        message: `İfade bekleniyordu, '${t.value}' bulundu.`,
      });
    while (this.match("[")) {
      const ix = this.expression();
      this.need("]");
      e = { kind: "index", target: e, index: ix, at: e.at };
    }
    return e;
  }
}
