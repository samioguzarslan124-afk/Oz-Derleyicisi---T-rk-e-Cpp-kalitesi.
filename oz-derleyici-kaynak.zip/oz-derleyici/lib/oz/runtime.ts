import type {
  Expr,
  HostIO,
  Program,
  RunResult,
  Stmt,
  Value,
  ValueType,
} from "./types";

const show = (v: Value): string =>
  Array.isArray(v)
    ? `[${v.map(show).join(", ")}]`
    : v === null
      ? "bos"
      : typeof v === "boolean"
        ? v
          ? "dogru"
          : "yanlis"
        : String(v);
class ReturnSignal {
  constructor(public value: Value) {}
}
class BreakSignal {}
class ContinueSignal {}
class VM {
  scopes: Map<string, { value: Value; type: ValueType }>[] = [new Map()];
  functions = new Map<string, Extract<Stmt, { kind: "function" }>>();
  output: string[] = [];
  private steps = 0;
  constructor(
    private program: Program,
    private io: HostIO,
  ) {
    for (const s of program.body)
      if (s.kind === "function") this.functions.set(s.name, s);
  }
  private tick() {
    this.steps += 1;
    if (this.steps > 50_000)
      throw Error("Güvenlik sınırı: program 50.000 çalıştırma adımını aştı.");
  }
  get(n: string): { value: Value; type: ValueType } {
    for (let i = this.scopes.length - 1; i >= 0; i--) {
      const x = this.scopes[i].get(n);
      if (x) return x;
    }
    throw Error(`'${n}' değişkeni bulunamadı.`);
  }
  set(n: string, v: Value) {
    for (let i = this.scopes.length - 1; i >= 0; i--) {
      const x = this.scopes[i].get(n);
      if (x) {
        x.value = v;
        return;
      }
    }
    throw Error(`'${n}' değişkeni bulunamadı.`);
  }
  expr(e: Expr): Value {
    switch (e.kind) {
      case "literal":
        return e.value;
      case "variable":
        return this.get(e.name).value;
      case "array":
        return e.items.map((x) => this.expr(x));
      case "index": {
        const a = this.expr(e.target),
          i = this.expr(e.index);
        if (
          !Array.isArray(a) ||
          typeof i !== "number" ||
          !Number.isInteger(i) ||
          i < 0 ||
          i >= a.length
        )
          throw Error("Dizi indisi aralık dışında veya geçersiz.");
        return a[i];
      }
      case "unary": {
        const v = this.expr(e.operand);
        if (e.op === "!") return !v;
        if (typeof v !== "number")
          throw Error("Sayısal tekli işlem bekleniyor.");
        return e.op === "-" ? -v : v;
      }
      case "binary": {
        const a = this.expr(e.left);
        if (e.op === "&&") return Boolean(a) && Boolean(this.expr(e.right));
        if (e.op === "||") return Boolean(a) || Boolean(this.expr(e.right));
        const b = this.expr(e.right);
        switch (e.op) {
          case "+":
            return typeof a === "string" || typeof b === "string"
              ? show(a) + show(b)
              : Number(a) + Number(b);
          case "-":
            return Number(a) - Number(b);
          case "*":
            return Number(a) * Number(b);
          case "/":
            if (Number(b) === 0) throw Error("Sıfıra bölme.");
            return Number(a) / Number(b);
          case "%":
            if (Number(b) === 0) throw Error("Sıfıra bölme.");
            return Number(a) % Number(b);
          case "==":
            return a === b;
          case "!=":
            return a !== b;
          case "<":
            return (a as any) < (b as any);
          case ">":
            return (a as any) > (b as any);
          case "<=":
            return (a as any) <= (b as any);
          default:
            return (a as any) >= (b as any);
        }
      }
      case "call": {
        const f = this.functions.get(e.name);
        if (!f) throw Error(`Fonksiyon '${e.name}' bulunamadı.`);
        if (f.params.length !== e.args.length)
          throw Error(`'${e.name}' argüman sayısı yanlış.`);
        const vals = e.args.map((a) => this.expr(a));
        const old = this.scopes;
        this.scopes = [new Map()];
        f.params.forEach((p, i) =>
          this.scopes[0].set(p.name, { value: vals[i], type: p.type }),
        );
        try {
          this.syncStmt(f.body);
          return null;
        } catch (x) {
          if (x instanceof ReturnSignal) return x.value;
          throw x;
        } finally {
          this.scopes = old;
        }
      }
    }
  }
  syncStmt(s: Stmt): void {
    this.tick();
    switch (s.kind) {
      case "block":
        this.scopes.push(new Map());
        try {
          for (const x of s.body) this.syncStmt(x);
        } finally {
          this.scopes.pop();
        }
        return;
      case "declare":
        this.scopes[this.scopes.length - 1].set(s.name, {
          value: s.init ? this.expr(s.init) : null,
          type: s.type,
        });
        return;
      case "assign": {
        const v = this.expr(s.value);
        if (s.target.kind === "variable") this.set(s.target.name, v);
        else if (s.target.kind === "index") {
          const a = this.expr(s.target.target),
            i = this.expr(s.target.index);
          if (
            !Array.isArray(a) ||
            typeof i !== "number" ||
            i < 0 ||
            i >= a.length
          )
            throw Error("Dizi indisi aralık dışında.");
          a[i] = v;
        }
        return;
      }
      case "expr":
        this.expr(s.expr);
        return;
      case "print": {
        const v = show(this.expr(s.value));
        this.output.push(v);
        this.io.write(v);
        return;
      }
      case "if":
        this.syncStmt(
          this.expr(s.test)
            ? s.yes
            : (s.no ?? { kind: "block", body: [], at: s.at }),
        );
        return;
      case "while":
        while (this.expr(s.test)) {
          try {
            this.syncStmt(s.body);
          } catch (e) {
            if (e instanceof BreakSignal) break;
            if (!(e instanceof ContinueSignal)) throw e;
          }
        }
        return;
      case "for":
        this.scopes.push(new Map());
        try {
          if (s.init) this.syncStmt(s.init);
          while (s.test ? Boolean(this.expr(s.test)) : true) {
            try {
              this.syncStmt(s.body);
            } catch (e) {
              if (e instanceof BreakSignal) break;
              if (!(e instanceof ContinueSignal)) throw e;
            }
            if (s.step) this.syncStmt(s.step);
          }
        } finally {
          this.scopes.pop();
        }
        return;
      case "return":
        throw new ReturnSignal(s.value ? this.expr(s.value) : null);
      case "break":
        throw new BreakSignal();
      case "continue":
        throw new ContinueSignal();
      case "function":
        return;
      default:
        throw Error("Fonksiyon içinde bu ifade desteklenmiyor.");
    }
  }
  async stmt(s: Stmt): Promise<void> {
    this.tick();
    switch (s.kind) {
      case "block":
        this.scopes.push(new Map());
        try {
          for (const x of s.body) await this.stmt(x);
        } finally {
          this.scopes.pop();
        }
        return;
      case "declare":
        this.scopes[this.scopes.length - 1].set(s.name, {
          value: s.init ? this.expr(s.init) : null,
          type: s.type,
        });
        return;
      case "assign": {
        const v = this.expr(s.value);
        if (s.target.kind === "variable") this.set(s.target.name, v);
        else if (s.target.kind === "index") {
          const a = this.expr(s.target.target);
          if (!Array.isArray(a)) throw Error("Atama hedefi dizi değil.");
          const i = this.expr(s.target.index);
          if (
            typeof i !== "number" ||
            !Number.isInteger(i) ||
            i < 0 ||
            i >= a.length
          )
            throw Error("Dizi indisi aralık dışında.");
          a[i] = v;
        } else throw Error("Geçersiz atama hedefi.");
        return;
      }
      case "expr":
        this.expr(s.expr);
        return;
      case "print": {
        const v = show(this.expr(s.value));
        this.output.push(v);
        this.io.write(v);
        return;
      }
      case "input": {
        const prompt = s.prompt ? show(this.expr(s.prompt)) : "";
        if (s.target.kind !== "variable")
          throw Error("oku hedefi değişken olmalı.");
        const cell = this.get(s.target.name);
        const raw = await this.io.read(prompt, cell.type);
        let val: Value = raw;
        if (cell.type === "tam" || cell.type === "ondalik") {
          val = Number(raw);
          if (!Number.isFinite(val)) throw Error("Girilen değer sayı değil.");
        }
        if (cell.type === "mantik") {
          if (raw === "dogru" || raw === "true") val = true;
          else if (raw === "yanlis" || raw === "false") val = false;
          else throw Error("Mantik girişi dogru veya yanlis olmalı.");
        }
        this.set(s.target.name, val);
        return;
      }
      case "if":
        if (this.expr(s.test)) await this.stmt(s.yes);
        else if (s.no) await this.stmt(s.no);
        return;
      case "while":
        while (this.expr(s.test)) {
          try {
            await this.stmt(s.body);
          } catch (e) {
            if (e instanceof BreakSignal) break;
            if (!(e instanceof ContinueSignal)) throw e;
          }
        }
        return;
      case "for":
        this.scopes.push(new Map());
        try {
          if (s.init) await this.stmt(s.init);
          while (s.test ? Boolean(this.expr(s.test)) : true) {
            try {
              await this.stmt(s.body);
            } catch (e) {
              if (e instanceof BreakSignal) break;
              if (!(e instanceof ContinueSignal)) throw e;
            }
            if (s.step) await this.stmt(s.step);
          }
        } finally {
          this.scopes.pop();
        }
        return;
      case "break":
        throw new BreakSignal();
      case "continue":
        throw new ContinueSignal();
      case "return":
        throw new ReturnSignal(s.value ? this.expr(s.value) : null);
      case "function":
        return;
    }
  }
  async run(): Promise<RunResult> {
    try {
      for (const s of this.program.body)
        if (s.kind !== "function") await this.stmt(s);
      return { ok: true, output: this.output.join("\n") };
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      return {
        ok: false,
        output: this.output.join("\n"),
        error: message,
        diagnostics: [{ line: 1, column: 1, category: "runtime", message }],
      };
    }
  }
}
export function runProgram(
  program: Program,
  io: HostIO = { read: async () => "", write: () => {} },
): Promise<RunResult> {
  return new VM(program, io).run();
}
