import type { Diagnostic, Program } from "./types";
import { analyze } from "./analyzer";
import { lex } from "./lexer";
import { ParseError, Parser } from "./parser";
export { lex } from "./lexer";
export { runProgram } from "./runtime";
export type {
  Diagnostic,
  DiagnosticCategory,
  Expr,
  HostIO,
  Position,
  Program,
  RunResult,
  Stmt,
  Token,
  Value,
  ValueType,
} from "./types";

export function compileSource(source: string): {
  ok: boolean;
  program?: Program;
  diagnostics: Diagnostic[];
} {
  const l = lex(source);
  if (l.diagnostics.length) return { ok: false, diagnostics: l.diagnostics };
  try {
    const program = new Parser(l.tokens).parse();
    const diagnostics = analyze(program);
    return diagnostics.length
      ? { ok: false, program, diagnostics }
      : { ok: true, program, diagnostics: [] };
  } catch (e) {
    return {
      ok: false,
      diagnostics: [
        e instanceof ParseError
          ? e.diagnostic
          : { line: 1, column: 1, category: "syntax", message: String(e) },
      ],
    };
  }
}
