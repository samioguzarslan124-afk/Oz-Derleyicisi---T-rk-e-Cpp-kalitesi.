import type {
  Diagnostic,
  Expr,
  Position,
  Program,
  Stmt,
  ValueType,
} from "./types";

const infer = (e: Expr): ValueType => {
  if (e.kind === "literal")
    return typeof e.value === "number"
      ? Number.isInteger(e.value)
        ? "tam"
        : "ondalik"
      : typeof e.value === "string"
        ? "metin"
        : typeof e.value === "boolean"
          ? "mantik"
          : "bos";
  if (e.kind === "array")
    return (e.items.length ? `${infer(e.items[0])}[]` : "bos") as ValueType;
  if (e.kind === "unary") return e.op === "!" ? "mantik" : infer(e.operand);
  if (e.kind === "binary")
    return ["==", "!=", "<", ">", "<=", ">=", "&&", "||"].includes(e.op)
      ? "mantik"
      : e.op === "+" && infer(e.left) === "metin"
        ? "metin"
        : infer(e.left);
  return "bos";
};
export function analyze(p: Program): Diagnostic[] {
  const ds: Diagnostic[] = [];
  const globals = new Map<string, ValueType>(),
    funcs = new Map<
      string,
      { params: { name: string; type: ValueType }[]; returns: ValueType }
    >();
  for (const s of p.body) {
    if (s.kind === "declare") {
      if (globals.has(s.name))
        ds.push({
          ...s.at,
          category: "semantic",
          message: `'${s.name}' zaten tanımlı.`,
        });
    }
    if (s.kind === "function") {
      if (funcs.has(s.name) || globals.has(s.name))
        ds.push({
          ...s.at,
          category: "semantic",
          message: `'${s.name}' zaten tanımlı.`,
        });
      funcs.set(s.name, { params: s.params, returns: s.returns });
    }
  }
  const typeOf = (e: Expr, scopes: Map<string, ValueType>[]): ValueType => {
    if (e.kind === "literal") return infer(e);
    if (e.kind === "variable") {
      for (let i = scopes.length - 1; i >= 0; i--) {
        const found = scopes[i].get(e.name);
        if (found) return found;
      }
      return "bos";
    }
    if (e.kind === "call") return funcs.get(e.name)?.returns ?? "bos";
    if (e.kind === "index") {
      const target = typeOf(e.target, scopes);
      return target.endsWith("[]") ? (target.slice(0, -2) as ValueType) : "bos";
    }
    if (e.kind === "array") {
      const first = e.items[0];
      return (first ? `${typeOf(first, scopes)}[]` : "bos") as ValueType;
    }
    if (e.kind === "unary")
      return e.op === "!" ? "mantik" : typeOf(e.operand, scopes);
    if (["==", "!=", "<", ">", "<=", ">=", "&&", "||"].includes(e.op))
      return "mantik";
    if (
      e.op === "+" &&
      (typeOf(e.left, scopes) === "metin" ||
        typeOf(e.right, scopes) === "metin")
    )
      return "metin";
    return typeOf(e.left, scopes) === "ondalik" ||
      typeOf(e.right, scopes) === "ondalik"
      ? "ondalik"
      : typeOf(e.left, scopes);
  };
  const compatible = (expected: ValueType, actual: ValueType) =>
    expected === actual ||
    (expected === "ondalik" && actual === "tam") ||
    actual === "bos";
  const reportType = (at: Position, expected: ValueType, actual: ValueType) =>
    ds.push({
      ...at,
      category: "semantic",
      message: `Tür uyuşmazlığı: ${expected} bekleniyor, ${actual} bulundu.`,
    });
  const checkExpr = (e: Expr, scopes: Map<string, ValueType>[]) => {
    if (e.kind === "variable" && !scopes.some((scope) => scope.has(e.name))) {
      ds.push({
        ...e.at,
        category: "semantic",
        message: `'${e.name}' tanımlı değil.`,
      });
      return;
    }
    if (e.kind === "binary") {
      checkExpr(e.left, scopes);
      checkExpr(e.right, scopes);
      const left = typeOf(e.left, scopes),
        right = typeOf(e.right, scopes);
      if (
        ["&&", "||"].includes(e.op) &&
        (left !== "mantik" || right !== "mantik")
      )
        ds.push({
          ...e.at,
          category: "semantic",
          message: `'${e.op}' mantik değerleri bekler.`,
        });
      if (
        ["-", "*", "/", "%"].includes(e.op) &&
        (!["tam", "ondalik"].includes(left) ||
          !["tam", "ondalik"].includes(right))
      )
        ds.push({
          ...e.at,
          category: "semantic",
          message: `'${e.op}' sayısal değerler bekler.`,
        });
      if (e.op === "+" && !compatible(left, right) && !compatible(right, left))
        ds.push({
          ...e.at,
          category: "semantic",
          message: `Toplama uyumsuz türleri birleştiremez: ${left} ve ${right}.`,
        });
      return;
    }
    if (e.kind === "unary") {
      checkExpr(e.operand, scopes);
      const operand = typeOf(e.operand, scopes);
      if (
        e.op === "!"
          ? operand !== "mantik"
          : !["tam", "ondalik"].includes(operand)
      )
        ds.push({
          ...e.at,
          category: "semantic",
          message: `'${e.op}' işlecinde uyumsuz tür: ${operand}.`,
        });
    }
    if (e.kind === "array") e.items.forEach((item) => checkExpr(item, scopes));
    if (e.kind === "call") {
      const signature = funcs.get(e.name);
      if (!signature)
        ds.push({
          ...e.at,
          category: "semantic",
          message: `Fonksiyon '${e.name}' tanımlı değil.`,
        });
      else {
        if (signature.params.length !== e.args.length)
          ds.push({
            ...e.at,
            category: "semantic",
            message: `'${e.name}' ${signature.params.length} parametre bekliyor, ${e.args.length} verildi.`,
          });
        e.args.forEach((arg, i) => {
          checkExpr(arg, scopes);
          const expected = signature.params[i]?.type;
          if (expected && !compatible(expected, typeOf(arg, scopes)))
            reportType(arg.at, expected, typeOf(arg, scopes));
        });
      }
    }
    if (e.kind === "index") {
      checkExpr(e.target, scopes);
      checkExpr(e.index, scopes);
      if (!typeOf(e.target, scopes).endsWith("[]"))
        ds.push({
          ...e.at,
          category: "semantic",
          message: "Dizi türü indekslenebilir.",
        });
      if (typeOf(e.index, scopes) !== "tam")
        ds.push({
          ...e.index.at,
          category: "semantic",
          message: "Dizi indisi tam türünde olmalıdır.",
        });
    }
  };
  const block = (s: Stmt, scopes: Map<string, ValueType>[], loop = false) => {
    if (s.kind === "block") {
      const n = new Map<string, ValueType>();
      scopes = [...scopes, n];
      s.body.forEach((x) => block(x, scopes, loop));
      return;
    }
    if (s.kind === "declare") {
      const scope = scopes[scopes.length - 1];
      if (scope.has(s.name))
        ds.push({
          ...s.at,
          category: "semantic",
          message: `'${s.name}' aynı blokta zaten tanımlı.`,
        });
      scope.set(s.name, s.type);
      if (s.init) {
        checkExpr(s.init, scopes);
        const it = typeOf(s.init, scopes);
        if (
          it !== "bos" &&
          s.type !== "bos" &&
          it !== s.type &&
          !(s.type === "ondalik" && it === "tam")
        )
          ds.push({
            ...s.at,
            category: "semantic",
            message: `'${s.name}' için ${s.type} bekleniyor, ${it} bulundu.`,
          });
      }
      return;
    }
    if (s.kind === "assign") {
      checkExpr(s.target, scopes);
      checkExpr(s.value, scopes);
      let expected: ValueType | undefined;
      if (s.target.kind === "variable") {
        for (let i = scopes.length - 1; i >= 0; i--) {
          expected = scopes[i].get(s.target.name);
          if (expected) break;
        }
      } else if (s.target.kind === "index") expected = typeOf(s.target, scopes);
      if (expected && !compatible(expected, typeOf(s.value, scopes)))
        reportType(s.at, expected, typeOf(s.value, scopes));
      return;
    }
    if (s.kind === "expr") checkExpr(s.expr, scopes);
    if (s.kind === "print") checkExpr(s.value, scopes);
    if (s.kind === "input") {
      if (s.prompt) checkExpr(s.prompt, scopes);
      checkExpr(s.target, scopes);
    }
    if (s.kind === "if") {
      checkExpr(s.test, scopes);
      if (typeOf(s.test, scopes) !== "mantik")
        ds.push({
          ...s.test.at,
          category: "semantic",
          message: "eger koşulu mantik türünde olmalıdır.",
        });
      block(s.yes, scopes, loop);
      if (s.no) block(s.no, scopes, loop);
    }
    if (s.kind === "while" || s.kind === "for") {
      if (s.kind === "while") {
        checkExpr(s.test, scopes);
        if (typeOf(s.test, scopes) !== "mantik")
          ds.push({
            ...s.test.at,
            category: "semantic",
            message: "iken koşulu mantik türünde olmalıdır.",
          });
      }
      const local = new Map<string, ValueType>();
      const inner = [...scopes, local];
      if (s.kind === "for") {
        if (s.init) block(s.init, inner, true);
        if (s.test) {
          checkExpr(s.test, inner);
          if (typeOf(s.test, inner) !== "mantik")
            ds.push({
              ...s.test.at,
              category: "semantic",
              message: "dongu koşulu mantik türünde olmalıdır.",
            });
        }
        if (s.step) block(s.step, inner, true);
      }
      block(s.body, inner, true);
    }
    if ((s.kind === "break" || s.kind === "continue") && !loop)
      ds.push({
        ...s.at,
        category: "semantic",
        message: "Bu ifade yalnızca döngü içinde kullanılabilir.",
      });
    if (s.kind === "return" && s.value) checkExpr(s.value, scopes);
    if (s.kind === "function") {
      const local = new Map(s.params.map((x) => [x.name, x.type]));
      block(s.body, [...scopes, local]);
    }
  };
  p.body.forEach((s) => block(s, [globals]));
  return ds;
}
