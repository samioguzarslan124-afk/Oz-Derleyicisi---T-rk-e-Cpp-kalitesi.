export const EXAMPLES = [
  {
    name: "Merhaba",
    source: 'program Merhaba {\n  yazdir("Merhaba, Öz!");\n}',
  },
  {
    name: "Döngü",
    source:
      "program Dongu {\n  tam toplam = 0;\n  dongu (tam i = 1; i <= 5; i = i + 1) {\n    toplam = toplam + i;\n  }\n  yazdir(toplam);\n}",
  },
  {
    name: "Fonksiyon",
    source:
      "program Faktoriyel {\n  tam sonuc = faktoriyel(5);\n  yazdir(sonuc);\n}\nfonksiyon tam faktoriyel(tam n) {\n  eger (n <= 1) { dondur 1; }\n  dondur n * faktoriyel(n - 1);\n}",
  },
  {
    name: "Dizi",
    source:
      "program Dizi {\n  tam[] sayilar = [2, 4, 6];\n  yazdir(sayilar[1]);\n}",
  },
];
