import { describe, expect, it } from "vitest";
import { compileSource, runProgram } from "../lib/oz";
import { EXAMPLES } from "../lib/oz/examples";

describe("Öz compiler core", () => {
  it("compiles and executes declarations, loops, continue, and output", async () => {
    const compiled = compileSource(
      `program Ana { tam toplam = 0; dongu (tam i = 0; i < 4; i = i + 1) { eger (i == 2) { devam; } toplam = toplam + i; } yazdir(toplam); }`,
    );
    expect(compiled.ok).toBe(true);
    const result = await runProgram(compiled.program!, {
      read: async () => "",
      write: () => {},
    });
    expect(result).toMatchObject({ ok: true, output: "4" });
  });
  it("reports lexical and syntax diagnostics with locations", () => {
    expect(compileSource("tam x = @;").diagnostics[0]).toMatchObject({
      category: "lexical",
      line: 1,
      column: 9,
    });
    expect(
      compileSource("eger (dogru) yazdir(1;").diagnostics[0],
    ).toMatchObject({ category: "syntax", line: 1 });
  });
  it("prevents invalid programs and catches undeclared variables", () => {
    const compiled = compileSource("program Ana { yazdir(eksik); }");
    expect(compiled.ok).toBe(false);
    expect(compiled.diagnostics[0].category).toBe("semantic");
  });
  it("supports functions, arrays, Turkish identifiers, and injected input", async () => {
    const good = compileSource(
      `fonksiyon tam iki(tam n) { dondur n * 2; } program Ana { tam[] sayilar = [1, 2]; tam cevap = iki(sayilar[1]); metin isim; oku(isim); yazdir(cevap); yazdir(isim); }`,
    );
    expect(good.ok).toBe(true);
    let prompt = "";
    const result = await runProgram(good.program!, {
      read: async (p) => {
        prompt = p;
        return "Öz";
      },
      write: () => {},
    });
    expect(result).toMatchObject({ ok: true, output: "4\nÖz" });
    expect(prompt).toBe("");
  });
  it("blok kapsamındaki tür uyuşmazlığını yazım denetiminden ayrı yakalar", () => {
    const compiled = compileSource(
      'program Ana { tam sayi = 7; sayi = "yanlış tür"; }',
    );
    expect(compiled.ok).toBe(false);
    expect(compiled.diagnostics[0]).toMatchObject({
      category: "semantic",
      line: 1,
    });
  });

  it("fonksiyon içinde döngüleri çalıştırır ve sonsuz döngüyü sınırlar", async () => {
    const functionProgram = compileSource(
      `fonksiyon tam topla(tam limit) { tam toplam = 0; dongu (tam i = 0; i < limit; i = i + 1) { toplam = toplam + i; } dondur toplam; } program Ana { yazdir(topla(5)); }`,
    );
    expect(functionProgram.ok).toBe(true);
    const normal = await runProgram(functionProgram.program!);
    expect(normal).toMatchObject({ ok: true, output: "10" });
    const infinite = compileSource("program Sonsuz { iken (dogru) { } }");
    expect(infinite.ok).toBe(true);
    const stopped = await runProgram(infinite.program!);
    expect(stopped.ok).toBe(false);
    if (!stopped.ok) expect(stopped.error).toContain("50.000");
  });

  it("derleyip tüm yerleşik örnek programları çalıştırır", async () => {
    for (const example of EXAMPLES) {
      const compiled = compileSource(example.source);
      expect(compiled.ok, example.name).toBe(true);
      const result = await runProgram(compiled.program!, {
        read: async () => "Sami",
        write: () => {},
      });
      expect(result.ok, example.name).toBe(true);
      if (example.name === "Faktoriyel") expect(result.output).toContain("120");
    }
  });
});
