# Katkıda bulunma

1. Bir konu açıp değişikliği/Ö dil özelliğini kısaca tarif edin.
2. Küçük ve odaklı bir dal/PR hazırlayın; kullanıcı arayüzü metinlerini Türkçe tutun.
3. Derleyici değişikliklerinde en az bir başarı ve bir hata senaryosu için Vitest testi ekleyin.
4. `pnpm test` ve `pnpm exec tsc --noEmit` komutlarını çalıştırın. Android derleme değiştiyse `.github/workflows/android-apk.yml`'in Artifact adımını koruyun.
5. Tanılamalar satır/sütun ve hata kategorisi taşımalı; dil dışı yazım/typo denetimi eklemeyin.
6. Keyfî shell/syscall çalıştırma veya güvenlik sınırlarını aşan I/O eklemeyin.

Katkılar MIT lisansıyla dağıtılacaktır.
