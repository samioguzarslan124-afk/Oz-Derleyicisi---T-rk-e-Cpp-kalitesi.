# Öz Derleyici — Uygulama Planı

## Hedef ve yaklaşım

Öz dil şartnamesini çevrimdışı ve düşük kaynakla çalıştıran bir React Native / Expo Android uygulaması. Derleyici saf TypeScript modüllerinden oluşur: lexer, recursive-descent parser, küçük statik tür denetimi ve kontrollü tree-walk yorumlayıcı. Kod kullanıcı cihazında çalışır; LLM, ağ derlemesi veya ayrı sunucu gerektirmez. Hatalar yazım denetimi değildir: dil kurallarına aykırı token/sözdizimi/tür hataları anında denetlenir, hatalı satırlar editör cetvelinde kırmızıyla işaretlenir ve derleme/çalıştırma engellenir.

C++'taki keyfî native/shell erişiminin mobilde güvenli karşılığı olarak ilk sürüm yalnızca izinli uygulama içi işlemler sağlar: konsola yazdırma, kullanıcıdan oku ve kontrollü dosya API'si. Shell komutları, keyfî syscall, süreç/OS belleği erişimi veya izin atlatma yoktur. `oku` mobil uygulamadaki giriş alanından değer alır. Derleyici, kullanıcı girdisi bekleyen yürütmeyi duraklatıp uygulamaya girdi isteği döndürür.

Android APK üretimi için `.github/workflows/android-apk.yml` GitHub Actions iş akışı eklenecek: Node/pnpm ile bağımlılık kurulumu, Expo prebuild, Gradle release APK derlemesi ve APK artifact yüklemesi. Mobil WebDev deposu GitHub'a kanonik bağlanamadığı ve Actions bu repo üzerinde çalıştırılamadığı için iş akışı kaynakta hazır bulunacak; bağımsız GitHub'a kullanıcı aktarımı ve gerçek Actions çalıştırması bu oturumda garanti edilemez. APK üretilmiş gibi sunulmayacak.

## Yapı ve modüller

- `app/(tabs)/index.tsx`: tek ekranlı Öz IDE; editör, örnek seçimi, hızlı derleme/çalıştırma, çıktı ve tanılamalar.
- `lib/oz/lexer.ts`: UTF-8/Türkçe tanımlayıcılar, konum takibi ve tokenlaştırma.
- `lib/oz/parser.ts`: program/fonksiyon, deklarasyon, blok, koşul, döngü, I/O ve ifade AST'si.
- `lib/oz/analyzer.ts`: blok kapsamı, isim/tür ve dönüş kontrolü.
- `lib/oz/interpreter.ts`: izinli yerel yürütme, çıktı ve `oku` devam durumu.
- `lib/oz/index.ts`, `lib/oz/types.ts`, `lib/oz/examples.ts`: dış API, AST/tanı tipleri ve kısa örnekler.
- `__tests__/oz.test.ts`: lexer, parser, tür hatası ve çalışma zamanı için Vitest testleri.
- `.github/workflows/android-apk.yml`: kullanıcı tarafından GitHub'a kopyalandığında artifact veren Android release workflow'u.
- `README.md`, `LICENSE`, `.gitignore`: açık kaynak kullanım/kurulum, MIT lisansı ve generated Android/cache çıktılarını dışlama.
- `plan.md`, `TODO.md`: plan ve gerçekleşen kapsam.

## Tasarım

Üç olası yön: Sinyal Laboratuvarı (%0.08), Anadolu Terminali (%0.07), Kâğıt Üstünde Kod (%0.06). Seçilen yön, Blueprint'te seçilmiş olan **Sinyal Laboratuvarı**: kömür grisi arayüz, elektrik yeşili etkileşim ve hatalar için kırmızı; mobil ekranda üstte dar derleme durum çubuğu, editör ve alt çekmece tarzında çıktı/tanılama bölümü.

- **Tasarım hareketi:** deneysel, modüler geliştirici laboratuvarı.
- **İlkeler:** editör öncelikli; tanılamalar anında ve konumlu; düşük gecikme/düşük kaynak; erişilebilir kontrast.
- **Renk:** kömür yüzey odaklanmayı, elektrik yeşili başarılı derlemeyi, koyu kırmızı kaynak satırı işaretlerini belirtir.
- **Yerleşim:** dikey çalışma tezgâhı; üstte ürün/derleme eylemleri, orta bölümde satır cetvelli editör, altta sonuç paneli.
- **İmza:** durum LED'i, hatalı satırlarda kırmızı cetvel, mono font kod alanı.
- **Etkileşim:** tek elle çalışan belirgin Derle/Çalıştır, örnek geçişi; hataya dokununca kaynak satırı seçilir.
- **Animasyon:** durum değişiminde kısa opaklık geçişi; bloklayan/uzun animasyon yok.
- **Tipografi:** sistem sans başlıklar ve monospace kod/çıktı; varsayılan fontlar, ek font bağımlılığı yok.
- **Marka:** “Öz'ü yaz, anında çalıştır.” Kişilik: hızlı, titiz, açık.
- **Ses tonu:** kısa, teknik, Türkçe. Örnek: “Kod hazır.” / “3. satır: beklenen `;`.”
- **Logo:** elektrik yeşili köşeli parantez içinde stilize `Ö` glyph'i; kare ikon.
- **İmza rengi:** `#65E572`.

## Sınırlar

İlk sürüm şartnamede tanımlanmayan pointer, bellek yönetimi, eşzamanlılık, modül/import sistemi veya keyfî işletim sistemi erişimini vaat etmez. Dizi literal/index desteği ilk aşamada yalnızca statik ve güvenli yürütülebilen temel biçimlerle sınırlanır; eksik tanımlar açık hata verir. WebDev mobil starter'ın sabit Expo stack'i ve portları korunur.
