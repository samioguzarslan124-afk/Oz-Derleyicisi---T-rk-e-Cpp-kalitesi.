import { useEffect, useMemo, useRef, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type NativeSyntheticEvent,
  type TextInputSelectionChangeEventData,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { compileSource, runProgram } from "@/lib/oz";
import { EXAMPLES } from "@/lib/oz/examples";
import type { Diagnostic } from "@/lib/oz/types";
const C = {
  bg: "#111416",
  panel: "#1A1F21",
  panel2: "#202729",
  border: "#30383A",
  text: "#E7ECE9",
  muted: "#8E9B96",
  green: "#65E572",
  red: "#FF626B",
};
const INITIAL = `program AnaProgram {
    tam sayi = 7;
    tam sonuc = faktoriyel(sayi);
    yazdir("Öz hazır: ");
    yazdir(sonuc);
}

fonksiyon tam faktoriyel(tam n) {
    eger (n <= 1) {
        dondur 1;
    }
    dondur n * faktoriyel(n - 1);
}`;
export default function HomeScreen() {
  const [source, setSource] = useState(INITIAL);
  const [diagnostics, setDiagnostics] = useState<Diagnostic[]>([]);
  const [output, setOutput] = useState(
    "Çıktı ve derleme durumu burada görünür.",
  );
  const [running, setRunning] = useState(false);
  const [showExamples, setShowExamples] = useState(false);
  const [inputPrompt, setInputPrompt] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [line, setLine] = useState(1);
  const [storageReady, setStorageReady] = useState(false);
  const inputResolver = useRef<((value: string) => void) | null>(null);
  const editorRef = useRef<TextInput>(null);
  const lines = useMemo(() => source.split("\n"), [source]);
  const errorLines = useMemo(
    () =>
      new Set(
        diagnostics
          .map((d) => d.line)
          .filter((n): n is number => typeof n === "number"),
      ),
    [diagnostics],
  );
  useEffect(() => {
    const timer = setTimeout(
      () => setDiagnostics(compileSource(source).diagnostics),
      130,
    );
    return () => clearTimeout(timer);
  }, [source]);
  const onSelectionChange = (
    event: NativeSyntheticEvent<TextInputSelectionChangeEventData>,
  ) =>
    setLine(
      source.slice(0, event.nativeEvent.selection.start).split("\n").length,
    );
  const run = async () => {
    const compilation = compileSource(source);
    setDiagnostics(compilation.diagnostics);
    if (!compilation.ok || !compilation.program) {
      setOutput(
        "Çalıştırma engellendi. Önce kırmızı işaretli dil hatalarını düzelt.",
      );
      return;
    }
    setRunning(true);
    setOutput("");
    try {
      const result = await runProgram(compilation.program, {
        write: (value: unknown) =>
          setOutput((old) => `${old}${String(value)}\n`),
        read: (prompt: string) =>
          new Promise<string>((resolve) => {
            inputResolver.current = resolve;
            setInputPrompt(prompt || "Değer girin");
            setInputValue("");
          }),
      });
      if (!result.ok)
        setOutput(
          result.output ? `${result.output}\n${result.error}` : result.error,
        );
      else if (result.output) setOutput(result.output);
    } catch (error) {
      setOutput(
        `Çalışma zamanı hatası: ${error instanceof Error ? error.message : String(error)}`,
      );
    } finally {
      setRunning(false);
      setInputPrompt(null);
    }
  };
  const submitInput = () => {
    inputResolver.current?.(inputValue);
    inputResolver.current = null;
    setInputPrompt(null);
    setOutput((old) => `${old}${inputPrompt}: ${inputValue}\n`);
  };
  const selectDiagnostic = (item: Diagnostic) => {
    if (!item.line) return;
    setLine(item.line);
    let offset = 0;
    for (let i = 1; i < item.line; i += 1)
      offset += (lines[i - 1]?.length ?? 0) + 1;
    offset += Math.max((item.column ?? 1) - 1, 0);
    editorRef.current?.focus();
    editorRef.current?.setNativeProps({
      selection: { start: offset, end: offset },
    });
  };
  return (
    <SafeAreaView style={s.safe} edges={["top", "bottom"]}>
      <View style={s.header}>
        <View style={s.brandRow}>
          <View style={s.mark}>
            <Text style={s.markText}>Ö</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.title}>
              ÖZ <Text style={{ color: C.green }}>DERLEYİCİ</Text>
            </Text>
            <Text style={s.subtitle}>YEREL · HIZLI · TÜRKÇE</Text>
          </View>
          <View
            style={[
              s.statusDot,
              { backgroundColor: diagnostics.length ? C.red : C.green },
            ]}
          />
        </View>
        <View style={s.toolbar}>
          <Pressable
            style={s.exampleButton}
            onPress={() => setShowExamples((v) => !v)}
          >
            <Text style={s.exampleText}>▤ ÖRNEKLER</Text>
          </Pressable>
          <Text style={s.fileLabel}>main.oz</Text>
          <Pressable
            disabled={running}
            onPress={run}
            style={[
              s.runButton,
              (running || diagnostics.length > 0) && s.runDisabled,
            ]}
          >
            <Text
              style={[
                s.runText,
                (running || diagnostics.length > 0) && { color: C.muted },
              ]}
            >
              {running
                ? "ÇALIŞIYOR…"
                : diagnostics.length
                  ? "HATALARI DÜZELT"
                  : "▶  DERLE / ÇALIŞTIR"}
            </Text>
          </Pressable>
        </View>
      </View>
      {showExamples && (
        <ScrollView
          horizontal
          style={s.exampleStrip}
          contentContainerStyle={s.exampleContent}
        >
          {EXAMPLES.map((example) => (
            <Pressable
              key={example.name}
              style={s.exampleChip}
              onPress={() => {
                setSource(example.source);
                setShowExamples(false);
                setOutput(`“${example.name}” örneği yüklendi.`);
              }}
            >
              <Text style={s.exampleChipText}>{example.name}</Text>
            </Pressable>
          ))}
        </ScrollView>
      )}
      <View style={s.editorMeta}>
        <Text style={s.sectionLabel}>KAYNAK KODU</Text>
        <Text style={s.metaInfo}>
          UTF-8 · Satır {line} ·{" "}
          {diagnostics.length ? `${diagnostics.length} hata` : "Temiz"}
        </Text>
      </View>
      <View style={s.editorFrame}>
        <ScrollView
          style={s.gutterScroll}
          contentContainerStyle={s.gutterContent}
        >
          {lines.map((_, i) => {
            const n = i + 1,
              bad = errorLines.has(n);
            return (
              <Pressable
                key={n}
                onPress={() =>
                  selectDiagnostic(
                    diagnostics.find((d) => d.line === n) ??
                      ({ line: n, column: 1 } as Diagnostic),
                  )
                }
                style={[
                  s.gutterLine,
                  bad && s.gutterLineError,
                  n === line && !bad && s.gutterLineActive,
                ]}
              >
                <Text style={[s.gutterNumber, bad && s.gutterNumberError]}>
                  {String(n).padStart(2, "0")}
                  {bad ? " !" : "  "}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
        <TextInput
          ref={editorRef}
          value={source}
          onChangeText={setSource}
          onSelectionChange={onSelectionChange}
          multiline
          autoCapitalize="none"
          autoCorrect={false}
          spellCheck={false}
          textAlignVertical="top"
          selectionColor={C.green}
          style={s.editor}
          accessibilityLabel="Ö kaynak kodu editörü"
          placeholder={'program AnaProgram {\n    yazdir("Merhaba");\n}'}
          placeholderTextColor="#64706B"
        />
      </View>
      <View style={s.editorFoot}>
        <Text style={s.helperText}>
          Dil hataları kırmızıyla işaretlenir · Yazım denetimi kapalı
        </Text>
        <Text style={s.counter}>
          {storageReady ? "OTOMATİK KAYIT  ·  " : ""}
          {source.length} KARAKTER
        </Text>
      </View>
      <View style={s.bottom}>
        <View style={s.panelTabs}>
          <Text style={s.panelTabActive}>TANI & ÇIKTI</Text>
          <View style={s.compileBadge}>
            <Text style={s.compileBadgeText}>
              {diagnostics.length
                ? `${diagnostics.length} HATA`
                : "DERLEYİCİ HAZIR"}
            </Text>
          </View>
        </View>
        {diagnostics.length > 0 ? (
          <ScrollView style={s.diagnostics} keyboardShouldPersistTaps="handled">
            {diagnostics.slice(0, 8).map((d, i) => (
              <Pressable
                key={`${d.line}-${d.column}-${i}`}
                style={s.diagnosticRow}
                onPress={() => selectDiagnostic(d)}
              >
                <Text style={s.errorGlyph}>●</Text>
                <View style={{ flex: 1 }}>
                  <Text style={s.diagnosticTitle}>
                    Satır {d.line ?? "?"}
                    {d.column ? `:${d.column}` : ""} · {d.category}
                  </Text>
                  <Text style={s.diagnosticMessage}>{d.message}</Text>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        ) : (
          <ScrollView
            style={s.outputPanel}
            contentContainerStyle={{ paddingBottom: 16 }}
          >
            <Text style={s.outputText}>
              {output || "Program çıktısı bekleniyor…"}
            </Text>
          </ScrollView>
        )}
      </View>
      {inputPrompt !== null && (
        <View style={s.inputOverlay}>
          <View style={s.inputCard}>
            <Text style={s.inputEyebrow}>Ö GİRDİ İSTEĞİ</Text>
            <Text style={s.inputTitle}>{inputPrompt}</Text>
            <TextInput
              value={inputValue}
              onChangeText={setInputValue}
              autoFocus
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="Değerinizi yazın"
              placeholderTextColor={C.muted}
              style={s.inputField}
              onSubmitEditing={submitInput}
            />
            <Pressable style={s.inputSubmit} onPress={submitInput}>
              <Text style={s.runText}>GÖNDER →</Text>
            </Pressable>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 11,
    marginBottom: 16,
  },
  mark: {
    width: 38,
    height: 38,
    borderWidth: 1.5,
    borderColor: C.green,
    borderRadius: 11,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#18231A",
  },
  markText: { color: C.green, fontWeight: "900", fontSize: 23 },
  title: { color: C.text, fontSize: 16, fontWeight: "900", letterSpacing: 1.2 },
  subtitle: {
    color: C.muted,
    fontSize: 9,
    fontWeight: "700",
    letterSpacing: 1.8,
    marginTop: 3,
  },
  statusDot: { width: 9, height: 9, borderRadius: 5, marginRight: 4 },
  toolbar: { flexDirection: "row", alignItems: "center", gap: 8 },
  exampleButton: {
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderColor: C.border,
    borderWidth: 1,
    borderRadius: 9,
  },
  exampleText: {
    color: C.text,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  fileLabel: {
    flex: 1,
    textAlign: "center",
    color: C.muted,
    fontFamily: "monospace",
    fontSize: 12,
  },
  runButton: {
    paddingVertical: 11,
    paddingHorizontal: 13,
    borderRadius: 9,
    backgroundColor: C.green,
  },
  runDisabled: { backgroundColor: C.panel2 },
  runText: { color: C.bg, fontWeight: "900", fontSize: 10, letterSpacing: 0.5 },
  exampleStrip: {
    maxHeight: 48,
    borderBottomColor: C.border,
    borderBottomWidth: 1,
  },
  exampleContent: { paddingHorizontal: 14, alignItems: "center", gap: 8 },
  exampleChip: {
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: 20,
    backgroundColor: C.panel2,
  },
  exampleChipText: { color: C.green, fontSize: 11, fontWeight: "700" },
  editorMeta: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 13,
    paddingBottom: 8,
  },
  sectionLabel: {
    color: C.muted,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  metaInfo: { color: C.muted, fontSize: 10, fontFamily: "monospace" },
  editorFrame: {
    flex: 1,
    minHeight: 180,
    flexDirection: "row",
    marginHorizontal: 12,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 12,
    overflow: "hidden",
  },
  gutterScroll: { width: 52, borderRightColor: C.border, borderRightWidth: 1 },
  gutterContent: { paddingTop: 13, paddingBottom: 24 },
  gutterLine: {
    minHeight: 22,
    justifyContent: "center",
    paddingLeft: 5,
    borderLeftWidth: 3,
    borderLeftColor: "transparent",
  },
  gutterLineActive: { backgroundColor: "#252D2E", borderLeftColor: C.green },
  gutterLineError: { backgroundColor: "#3A2023", borderLeftColor: C.red },
  gutterNumber: { color: "#73807A", fontFamily: "monospace", fontSize: 11 },
  gutterNumberError: { color: C.red, fontWeight: "900" },
  editor: {
    flex: 1,
    paddingHorizontal: 12,
    paddingTop: 13,
    paddingBottom: 24,
    color: C.text,
    fontFamily: "monospace",
    fontSize: 13,
    lineHeight: 22,
    textAlignVertical: "top",
  },
  editorFoot: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 10,
  },
  helperText: { color: C.muted, fontSize: 9 },
  counter: { color: C.muted, fontSize: 9, fontFamily: "monospace" },
  bottom: {
    minHeight: 168,
    maxHeight: 225,
    marginHorizontal: 12,
    marginBottom: 8,
    borderRadius: 12,
    backgroundColor: C.panel,
    borderWidth: 1,
    borderColor: C.border,
    overflow: "hidden",
  },
  panelTabs: {
    height: 39,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 13,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  panelTabActive: {
    color: C.text,
    fontWeight: "900",
    fontSize: 9,
    letterSpacing: 1,
  },
  compileBadge: {
    backgroundColor: "#203325",
    borderRadius: 5,
    paddingVertical: 4,
    paddingHorizontal: 7,
  },
  compileBadgeText: {
    color: C.green,
    fontWeight: "900",
    fontSize: 8,
    letterSpacing: 0.7,
  },
  diagnostics: { paddingHorizontal: 11, paddingVertical: 5 },
  diagnosticRow: {
    flexDirection: "row",
    gap: 9,
    paddingVertical: 7,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.border,
  },
  errorGlyph: { color: C.red, fontSize: 10, paddingTop: 2 },
  diagnosticTitle: { color: C.red, fontSize: 10, fontWeight: "800" },
  diagnosticMessage: { color: C.text, fontSize: 11, marginTop: 2 },
  outputPanel: { paddingHorizontal: 14, paddingTop: 13 },
  outputText: {
    color: C.green,
    fontFamily: "monospace",
    fontSize: 12,
    lineHeight: 19,
  },
  inputOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: "#000A",
    justifyContent: "center",
    padding: 20,
  },
  inputCard: {
    backgroundColor: C.panel,
    borderColor: C.green,
    borderWidth: 1,
    borderRadius: 16,
    padding: 18,
    gap: 10,
  },
  inputEyebrow: {
    color: C.green,
    fontSize: 9,
    fontWeight: "900",
    letterSpacing: 1.6,
  },
  inputTitle: { color: C.text, fontSize: 17, fontWeight: "700" },
  inputField: {
    borderColor: C.border,
    borderWidth: 1,
    borderRadius: 9,
    padding: 12,
    color: C.text,
    fontSize: 15,
  },
  inputSubmit: {
    alignSelf: "flex-end",
    backgroundColor: C.green,
    borderRadius: 8,
    paddingVertical: 11,
    paddingHorizontal: 15,
  },
});
