# TODO

## Dil derleyicisi ve güvenli çalışma zamanı
- [x] “Her çalıştırılabilir Öz programı bir `program` bloğu ile başlar.”
- [x] “UTF-8 (Türkçe karakterler değişken adlarında veya metin içeriklerinde desteklenir, ancak anahtar kelimeler ASCII uyumlu sade Türkçe kelimelerden seçilmiştir).”
- [x] “Tek satırlık yorum: `//` ile başlar, satır sonuna kadar yok sayılır. Çok satırlı yorum: `/*` ile başlar, `*/` ile biter.” Anahtar kelimeler, operatörler, ayraçlar ve değişken tanımlama şartnamedeki söz dizimine uyar.
- [ ] “`tam`: 32-bit veya 64-bit işaretli tam sayılar. `ondalik`: Çift duyarlıklı (double/float) ondalıklı sayılar. `metin`: çift tırnaklı karakter dizileri. `mantik`: sadece `dogru` veya `yanlis`. Diziler tip adının yanına `[]` eklenerek tanımlanır.” Şu an double tabanlı JavaScript `number` kullanılır; 64-bit tamsayı aritmetiği henüz eklenmedi.
- [x] “Değişkenler tanımlandıkları `{ }` bloğu içerisinde geçerlidir (Block Scope).”
- [x] `eger/degilse`, sayaçlı `dongu`, koşullu `iken`, `kir` ve `devam` akışı; yürütme 50.000 adımda sınırlandırılır.
- [ ] `fonksiyon` dönüş tipi/adı/parametreleri, `bos`, `dondur` ve özyinelemeli fonksiyonlar desteklenir. Fonksiyonlar, dönüş değeri ve özyineleme çalışır; dönüş ifadesinin bildirilen sonuç türüyle tam statik doğrulaması tamamlanmalı.
- [x] “`yazdir(ifade)`: Verilen metni, sayıyı veya değişken değerini konsola basar.” `oku(degisken)` kullanıcı girdisini belirtilen türe dönüştürüp değişkene atar.
- [x] Kod sözcüksel, sözdizimsel ve kısmi anlamsal tür denetiminden geçirilir; derleme hatasında çalıştırma engellenir; tanılamalar satır/sütun ve Türkçe açıklama taşır.
- [ ] “herhangi bir hata yazdığımız gibi yazmamıza izin vermesin ve hatalı satırı düzeltmamiz için kırmızı ile işartlesin. yazım hataları için geçerli değil.” Yazım denetimi kapalıdır; derleyici tanılamaları yaklaşık 250 ms içinde güncellenir, satır cetveli kırmızı işaretlenir ve hatalı kodun çalıştırılması engellenir. Düzenleyici, geçersiz taslak metnin geçici olarak yazılmasını bütünüyle önlemez.
- [ ] “hızlı olsun ve cpp gibi işletim sistemiyle konuşabilsin.” Programlar yerel yorumlayıcıda çalışır, LLM/ağ çağrısı yapmaz; kaynak taslağı cihaz içi uygulama depolamasında tutulur. Öz programlarından dosya/cihaz/OS API'lerine erişim henüz yoktur; keyfî shell/native syscall eklenmemiştir.

## Mobil uygulama
- [x] “bana bu dil için mobil derleyici yaz.” Uygulama `.oz` editörü, örnekler, derle/çalıştır, tanılamalar, etkileşimli giriş ve çıktı sunar; yazılan taslak AsyncStorage ile cihaz içinde otomatik saklanır.
- [x] “Expo Go yerine github actions ile derle ve bana ver.” Expo prebuild + Gradle APK + artifact yükleme GitHub Actions iş akışı `.github/workflows/android-apk.yml` içine eklendi. Gerçek APK artifact üretimi için GitHub Actions'ta çalıştırma bekleniyor.
- [x] Tek ekranlı Sinyal Laboratuvarı arayüzü; kömür yüzey, elektrik yeşili vurgu, monospace editör ve kırmızı hata cetveli.

## Açık kaynak ve repo/derleme belgeleri
- [x] “sıfırdan bir repo oluştur. açık kaynak kodlu yap.” Kod tabanına MIT lisansı, README, katkı, kurulum ve Android derleme adımları eklendi.
- [x] İş akışı Node/pnpm, Java 17, Expo prebuild ve Gradle `assembleRelease` ile APK artifact'i üretmek üzere hazırlandı.
- [ ] Kullanıcı GitHub hesabında public repo oluşturma/kaynağı yükleme ve Actions'ı fiilen çalıştırma yapılmadı; mobil WebDev reposu GitHub canonical olamıyor ve oturumda GitHub Connector bulunmuyor. Gerçek GitHub artifact APK'sı bu yüzden teslim edilmedi.
